Catecholamine_Enantiomers_Classifier

****************************************************************************************************************************************************

1. Introduction

Catecholamine_Enantiomers_Classifier is meant to serve as a machine learning-based nanopore analysis platform using MATLAB for the identification of different epinephrine and norepinephrine enantiomers. 

The program contains three steps as follows:
a. Import dataset including: training dataset and predicting dataset.                              
b. Train Classifier using training dataset and outputting validation accuracy, confusion matrix and decision boundary. 
c. Make predictions with the returned 'trainedClassifier' on predicting dataset and output predicted results. 

2. Operating procedures: 

-Unzip the ��Catecholamine_Enantiomers_Classifier.zip�� to local folder. One classifier is provided here. The classifier is trained for the identification of L-norepinephrine, D-norepinephrine, L-epinephrine and D-epinephrine, which is used to predict these four catecholamine enantiomers during sensing.  

-Open ��Catecholamine_Enantiomers_Classifier.m�� in MATLAB

-Enter the file name in line 5 to index the training dataset. // example: training_dataset.xlsx

-Enter the file name in line 6 to index the predicting dataset. // example: predicting_dataset.xlsx

-Specify names for the .xlsx files of the predict results at line 135. // example: predicting_dataset_results.xlsx

-Run ��Catecholamine_Enantiomers_Classifier.m��

3. Output

-The values of the variables 'validation Accuracy' is output in the command Widow. 

-Confusion matrix, decision boundary and scatter plot are plotted in the figure panel. 

-The results of the predicting dataset are output to the program folder in tabular form. 

clear;

% Step 1: Import dataset 

traindata = readtable('training_dataset.xlsx','PreserveVariableNames',true); %Import the training dataset   
predictdata = readtable('predicting_dataset.xlsx','PreserveVariableNames',true); %Import the predicting dataset   

% Step 2: Train linear SVM classifier 

% Extract predictors and response
% This code processes the data into the right shape for training the model.
predictorNames = {'amplitudeSD', 'percentageblockade'};
predictors = traindata(:, predictorNames);
response = traindata.lable;
isCategoricalPredictor = [false, false];

% Train a classifier
% This code specifies all the classifier options and trains the classifier.
template = templateSVM(...
    'KernelFunction', 'linear', ...
    'PolynomialOrder', [], ...
    'KernelScale', 'auto', ...
    'BoxConstraint', 1, ...
    'Standardize', true);
classificationSVM = fitcecoc(...
    predictors, ...
    response, ...
    'Learners', template, ...
    'Coding', 'onevsone', ...
    'ClassNames', categorical({'D-E'; 'D-N'; 'L-E'; 'L-N'}));

% Create the result struct with predict function
predictorExtractionFcn = @(t) t(:, predictorNames);
svmPredictFcn = @(x) predict(classificationSVM, x);
trainedClassifier.predictFcn = @(x) svmPredictFcn(predictorExtractionFcn(x));

% Add additional fields to the result struct
trainedClassifier.RequiredVariables = {'amplitudeSD', 'percentageblockade'};
trainedClassifier.ClassificationSVM = classificationSVM;
trainedClassifier.About = 'This struct is a trained model exported from Classification Learner R2019b.';
trainedClassifier.HowToPredict = sprintf('To make predictions on a new table, T, use: \n  yfit = c.predictFcn(T) \nreplacing ''c'' with the name of the variable that is this struct, e.g. ''trainedModel''. \n \nThe table, T, must contain the variables returned by: \n  c.RequiredVariables \nVariable formats (e.g. matrix/vector, datatype) must match the original training data. \nAdditional variables are ignored. \n \nFor more information, see <a href="matlab:helpview(fullfile(docroot, ''stats'', ''stats.map''), ''appclassification_exportmodeltoworkspace'')">How to predict using an exported model</a>.');

% Extract predictors and response
% This code processes the data into the right shape for training the model.

predictorNames = {'amplitudeSD', 'percentageblockade'};
predictors = traindata(:, predictorNames);
response = traindata.lable;
isCategoricalPredictor = [false, false];

% Perform cross-validation
partitionedModel = crossval(trainedClassifier.ClassificationSVM, 'KFold', 10);

% Compute validation predictions
[validationPredictions, validationScores] = kfoldPredict(partitionedModel);

% Compute resubstitution accuracy
resubstitutionAccuracy = 1 - resubLoss(trainedClassifier.ClassificationSVM);

% Compute validation accuracy
validationAccuracy = 1 - kfoldLoss(partitionedModel, 'LossFun', 'ClassifError');

% Output validation accuracy in the Command Widow
fprintf ('validationAccuracy = %.4f\n', validationAccuracy);

% Export confusion matrix
validationPredictions_cellstr = cellstr(validationPredictions);
figure(1);   
cm = confusionchart(response,validationPredictions_cellstr, ...
    'Title','confusion matrix', ...
    'RowSummary','row-normalized');

% Export decision boundary 
x_range = 1.3:0.01:3.0;   
y_range = -0.30:.001:-0.14;   
[grid_x_range, grid_y_range] = meshgrid(x_range,y_range);
grid = [grid_x_range(:) grid_y_range(:)];    
amplitudeSD = grid(:,1);
percentageblockade = grid(:,2);
decision_grid = table(amplitudeSD,percentageblockade);     
decision_lable = predict(trainedClassifier.ClassificationSVM,decision_grid); 

s_decision = string(decision_lable);
C1 = strrep(s_decision,'L-N','1');
C2 = strrep(C1,'D-N','2');
C3 = strrep(C2,'L-E','3');
C4 = strrep(C3,'D-E','4');
d_decision_label = str2double(C4);

% Plot decision boundary 
figure(2);   
decision_data = table(amplitudeSD, percentageblockade, d_decision_label);
d_decision_data = table2array(decision_data);
decision_color = d_decision_data(:,3);
sz = 15;
color = {[0,0.445313,0.738281],[0.847656,0.324219,0.097056],[0.925781,0.691406,0.125],[0.492188,0.183594,0.554688]};

for i = 1:4
    clust = find(decision_color==i);
    scatter(d_decision_data(clust,1),d_decision_data(clust,2),sz,color{i},'s','filled'); 
    hold on
end

% Image properties
xlim([1.3,3]);   
ylim([-0.30,-0.14]);
xticks([1.5 2.0 2.5 3.0]);   
yticks([-0.28 -0.24 -0.20 -0.16]);
xlabel('amplitudeSD')  
ylabel('percentageblockade');
legend('L-N', 'D-N', 'L-E','D-E','location', 'northeast');   
title('events of catecholamine enantiomers with decision boundary');
hold on;

% Plot scatter of mixture
mixdata= table2array(predictdata);
x_mixdata= mixdata(:,1);
y_mixdata= mixdata(:,2);
scatter(x_mixdata,y_mixdata,sz,'k','filled','MarkerFaceAlpha', 0.6);  
% Image properties
xlim([1.3,3]);   
ylim([-0.30,-0.14]);
xticks([1.5 2.0 2.5 3.0]);   
yticks([-0.28 -0.24 -0.20 -0.16]);
xlabel('amplitudeSD')   
ylabel('percentageblockade');
legend('L-N', 'D-N', 'L-E','D-E','location', 'northeast');    
hold off;

% Step 3: Make predictions with the returned 'trainedClassifier' on predicting dataset

% Export labels of the predicting dataset
predict_label = predict(trainedClassifier.ClassificationSVM,predictdata);  
predict_rusults =table(x_mixdata, y_mixdata, predict_label);
filename_predict = 'predicting_dataset_results.xlsx'; %Specify the file name of predict results
writetable(predict_rusults,filename_predict,'WriteRowNames',true);
